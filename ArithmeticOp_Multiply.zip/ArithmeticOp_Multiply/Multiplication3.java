package ArithmeticOp_Multiply;

public class Multiplication3 {
    long mul3(long k, long l) {
        long g = (k * l);
        return g;
    }

    public static void main(String[] args) {
        Multiplication3 oo = new Multiplication3();
        long into3 = oo.mul3(3451, 6548);
        System.out.println("multiply3=" + into3);
    }


}
