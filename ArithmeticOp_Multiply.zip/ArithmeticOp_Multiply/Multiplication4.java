package ArithmeticOp_Multiply;

public class Multiplication4 {

    void mul4(int m, int n) {
        int j = m * n;
        System.out.println("Multiply4=" + j);

    }

    public static void main(String[] args) {
        Multiplication4 uu = new Multiplication4();
        uu.mul4(9876, 3215);

    }
}
