package ArithmeticOp_Multiply;

public class Multiplication5 {

    void mul5(int l, int y) {
        int m = l * y;
        System.out.println("Multiply5=" + m);

    }

    public static void main(String[] args) {
        Multiplication5 uu = new Multiplication5();
        uu.mul5(487254, 35487);

        NewMultiplication nn = new NewMultiplication();
        nn.mul6(65, 78);

    }
}

class NewMultiplication {

    void mul6(int n, int c) {
        int q = n * c;
        System.out.println("Multiply6=" + q);

    }

}
