package ArithmeticOp_Add;

public class Addition1 {

    int add1(int a, int b) {
        return a + b;
    }

    public static void main(String[] args) {
        Addition1 aa = new Addition1();
        int add = aa.add1(60, 50);
        System.out.println("add1=" + add);
    }
}


