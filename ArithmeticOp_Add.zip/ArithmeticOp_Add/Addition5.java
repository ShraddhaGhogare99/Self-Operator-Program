package ArithmeticOp_Add;

public class Addition5 {

    void add6(int w, int r) {
        int f = w + r;
        System.out.println("add=" + f);

    }

    public static void main(String[] args) {
        Addition5 ww = new Addition5();
        ww.add6(96584, 31547);
        System.out.println();
    }

}
