package ArithmeticOp_Add;

public class Addition4 {

    void add5(int v, int h) {
        int g = v + h;
        System.out.println("add=" + g);
    }

    public static void main(String[] args) {
        Addition4 ii = new Addition4();
        ii.add5(987562, 315478);
        System.out.println();

    }
}
