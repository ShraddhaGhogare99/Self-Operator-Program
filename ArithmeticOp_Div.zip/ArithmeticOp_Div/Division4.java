package ArithmeticOp_Div;

public class Division4 {
    double div4(double x, double z) {
        double y = x / z;
        return y;

    }

    public static void main(String[] args) {
        Division4 oo = new Division4();
        double Div4 = oo.div4(6.3214548975, 2.6548792);
        System.out.println("divide4=" + Div4);
    }
}
