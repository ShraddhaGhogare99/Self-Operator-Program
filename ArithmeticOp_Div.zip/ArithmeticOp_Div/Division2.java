package ArithmeticOp_Div;

public class Division2 {

    int div2(int p, int q) {
        int o = p / q;
        return o;

    }

    public static void main(String[] args) {
        Division2 vv = new Division2();
        int Div2 = vv.div2(65489, 32145);
        System.out.println("divide2=" + Div2);
    }
}
