package ArithmeticOp_Div;

public class Division5 {
    void div5(int e, int p, int q) {
        int w = (e / p) / q;
        System.out.println("divide5=" + w);

    }

    public static void main(String[] args) {
        Division5 pp = new Division5();
        pp.div5(632147, 854, 14);
    }
}

