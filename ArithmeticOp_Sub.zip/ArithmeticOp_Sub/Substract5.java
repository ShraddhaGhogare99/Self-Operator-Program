package ArithmeticOp_Sub;

public class Substract5 {

    int Sub6(int l, int e, int y, int f) {
        int k = l - e - y - f;
        System.out.println("Sub6=" + k);
        return k;
    }

    public static void main(String[] args) {
        Substract5 aa = new Substract5();
        aa.Sub6(63548, 4256, 324, 97);
        System.out.println();
    }
}
