package ArithmeticOp_Sub;

public class Substract4 {

    void sub5(int h, int l) {
        int d = h - l;
        System.out.println("sub5=" + d);
    }

    public static void main(String[] args) {
        Substract4 rr = new Substract4();
        rr.sub5(96856, 4567);
        System.out.println();

    }
}

